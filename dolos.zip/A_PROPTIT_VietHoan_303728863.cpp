#include<stdio.h>
int main(){
printf("Xin chao At Ty 2025.");
}