#include<stdio.h>
int main(){
int n,m;
scanf("%d %d", &n, &m);
for (int i = 1; i <= n; ++i){
if (i % 2 == 0) {
for (int j = 1; j <= m; ++j) printf("P");
printf("\n");
}
else if (i % 4 == 1){
for (int j = 1; j < m; ++j) printf(".");
printf("P\n");
}
else if (i % 4 ==3){
printf("P");
for (int j = 1; j < m; ++j) printf(".");
printf("\n");
}
}
}